#include <iostream>
#include <string>
using namespace std;


// 1. Add an accept(Visitor) method to the "element" hierarchy
class Element
{
public:
    virtual void accept(class Visitor& v) = 0;
    virtual int progressReport() = 0;
    virtual float paidReport() = 0;
    virtual float remainingReport() = 0;
};

class A : public Element        // building A
{
public:
    void initial();
    void accept(Visitor& v);
    int progressReport() { return progress; }       // function to give report
    float paidReport() { return paid; }
    float remainingReport() { return remaining; }

private:
    int progress;               // variables only for building
    float paid;
    float remaining;
};
class B : public Element        // building B
{
public:
    void initial();
    void accept(Visitor& v);
    int progressReport() { return progress; }
    float paidReport() { return paid; }
    float remainingReport() { return remaining; }

private:
    int progress;
    float paid;
    float remaining;
};
void A::initial()
{
    progress = 40;
    paid = 1000000000;
    remaining = 3000000000;
}
void B::initial()
{
    progress = 55;
    paid = 2000000000;
    remaining = 4000000000;
}

// 2. Create a "visitor" base class w/ a visit() method for every "element" type

class Visitor   // inspector
{
public:
    virtual void visit(Element* e) = 0;     // visit buildings
};

void A::accept(class Visitor& v)
{
    v.visit(this);
}

void B::accept(class Visitor& v)
{
    v.visit(this);
}

// 3. Create a "visitor" derived class for each "operation" to do on "elements"
class InspectVisitor : public Visitor
{
    /*virtual*/void visit(Element* e)       // visit buildings and collect data
    {
        cout << "Progress (%):" << e->progressReport() << endl;
        cout << "Amount paid (USD):" << e->paidReport() << endl;
        cout << "Remaining amount (USD):" << e->remainingReport() << endl;
        cout << endl;
    }
};

int main()
{
    A a;        a.initial();
    B b;        b.initial();
    InspectVisitor v;

    // Start of the stimulation
    cout << "Inspection process:\n";
    cout << "Building A:\n";
    a.accept(v);
    cout << "Building B:\n";
    b.accept(v);
};