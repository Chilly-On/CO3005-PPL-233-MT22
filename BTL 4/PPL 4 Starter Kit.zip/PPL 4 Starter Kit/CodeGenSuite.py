import unittest
from TestUtils import TestCodeGen
from AST import *

class CheckCodeGenSuite(unittest.TestCase):
    def test500(self):
        input = """
        main: function void(){

        }
        """
        expect = ""
        self.assertTrue(TestCodeGen.test(input, expect, 500))
