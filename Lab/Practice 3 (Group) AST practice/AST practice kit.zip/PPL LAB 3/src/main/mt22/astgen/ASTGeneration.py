from MT22Visitor import MT22Visitor
from MT22Parser import MT22Parser
from AST import *

import collections.abc

class ASTGeneration(MT22Visitor):
    # Visit a parse tree produced by MT22Parser#program.
    def visitProgram(self, ctx:MT22Parser.ProgramContext):
        return Program([])