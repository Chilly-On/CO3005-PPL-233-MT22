import unittest
from TestUtils import TestAST
from AST import *

class ASTGenSuite(unittest.TestCase):

    def testcase300(self):
        testno = 300
        testcase = """5 + 4 * 3 - x / 2"""
        expect = """successfull"""
        self.assertTrue(TestAST.test(testcase, expect, testno))





